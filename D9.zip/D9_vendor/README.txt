#
# Copyright (C) 2013 JSR company
# If the violation of your rights,please contact us immediately delete.Our does not bear any responsibility.
#

1.Put the D9.patch file into Qualcomm MSM QRD2050 source code files.Diff Apply the D9.patch on Qualcomm MSM QRD2050 source code.
eg:patch -R -p1 < D9.patch
2.Unzip the folder of "proprietary" to the path of "vendor/qcom/ "
3.Make the source code and you will fine the .img file to test.